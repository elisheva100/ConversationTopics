#!/usr/bin/env python
# -*- coding: utf-8 -*-
from flask import Flask, request, render_template,jsonify
import flask
import gensim
import json
import glob
from nltk.tokenize import RegexpTokenizer
from nltk.stem.porter import PorterStemmer
from gensim import corpora
import numpy as np
import io
from flask_cors import CORS

# dictionary_file_name = './model/dictionary_en_tanach_without_stemming500topics_03'
# model_file_name = './model/lda_en_tanach_without_stemming_500topics_03'

model_file_name = './model/lda_en_tanach_without_stemming_200topics'
dictionary_file_name = './model/dictionary_en_tanach_without_stemming200topics'


class LdaModel(object):
    def __init__(self, model_path, dict_path):
        self._ldamodel = gensim.models.ldamodel.LdaModel.load(model_path)
        self._dictionary = corpora.Dictionary.load(dict_path)
        self._tokenizer = RegexpTokenizer(r'\w+')
        self._p_stemmer = PorterStemmer()

    def TextToTopic(self, doc_text):
        """Returns the topic for a given document.

        :param doc_text: A plain text of one document
        :return: A sorted (by val) list of tuples [(topic name, val in [0,1])]
        """
        if not doc_text:
            return []
        lower_doc_text = doc_text.lower()
        tokens = self._tokenizer.tokenize(lower_doc_text)

        print tokens

        bow = self._dictionary.doc2bow(tokens)
        doc_topics = self._ldamodel.get_document_topics(bow)

        if not doc_topics:
            return []
        print doc_topics

        top_doc_topic_id = sorted(doc_topics, key=lambda x: x[1], reverse=True)[0][0]
        top_topic = self._ldamodel.get_topic_terms(top_doc_topic_id, 5)
        return [(self._dictionary[x[0]], x[1])
                for x in sorted(top_topic, key=lambda k: k[1], reverse=True)]

class TzabarServer(object):
    def __init__(self, lda_model):
        self._app = Flask(__name__, template_folder='templates')
        self._lda_model = lda_model
        self._app.add_url_rule('/', 'self._Post', self._Post)
        cors = CORS(self._app, resources={r"/api/*": {"origins": "*"}})


    def _Post(self):
        param = flask.request.args.get('q')
        print param
        top_topics = self._lda_model.TextToTopic(param)
        print top_topics
        return jsonify(top_topics)




if __name__ == "__main__":
    lda_model = LdaModel(model_file_name, dictionary_file_name)
    server = TzabarServer(lda_model)
    server._app.run(debug=False, port=8000)
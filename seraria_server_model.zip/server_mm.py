#!/usr/bin/env python
# -*- coding: utf-8 -*-
from flask import Flask, request, render_template,jsonify
import flask
import gensim
import json
import glob
from nltk.tokenize import RegexpTokenizer
from nltk.stem.porter import PorterStemmer
from gensim import corpora
import numpy as np
import io
import os

# dictionary_file_name = './model/dictionary_en_tanach_without_stemming500topics_03'
# model_file_name = './model/lda_en_tanach_without_stemming_500topics_03'

model_file_name = './model/lda_en_tanach_without_stemming_200topics'
dictionary_file_name = './model/dictionary_en_tanach_without_stemming200topics'


file_list = [os.path.join(dp, f)
                     for dp, dn, filenames in os.walk('./data/Tanakh')
                     for f in filenames
                     if f == 'merged.json' and 'English' in dp]

print 'files: %s' % file_list

class LdaModel(object):
    def __init__(self, model_path, dict_path):
        self._ldamodel = gensim.models.ldamodel.LdaModel.load(model_path)
        self._dictionary = corpora.Dictionary.load(dict_path)
        self._tokenizer = RegexpTokenizer(r'\w+')
        self._p_stemmer = PorterStemmer()

        self._topic_id_to_chapters, self._book_to_text = self._DictTopicIdToChapter()


    def _UnpackNestedList(self, l):
        while len(l) > 0 and type(l[0]) == list:
            l = [x for y in l for x in y]
        return l

    def _DictTopicIdToChapter(self):
        topic_id_to_book = {}
        book_to_text = {}
        for book_file_name in file_list:
            book_dict = json.load(open(book_file_name))
            book_title = book_dict.get('title')
            book_text = book_dict.get('text')
            print 'reading %s' % book_title
            for i, doc in enumerate(book_text):
                doc_text = ' '.join(line for line in self._UnpackNestedList(doc))
                # print doc_text
                book_to_text['%s@%d' % (book_title, i)] = doc_text
                top_topic_id, score = self.TextToTopTopicId(doc_text)

                topic_id_to_book[top_topic_id] = topic_id_to_book.get(top_topic_id, []) + [('%s@%d' % (book_title, i), score)]

        for k, v in topic_id_to_book.iteritems():
            topic_id_to_book[k] = sorted(v, key=lambda k:k[1], reverse=True)[:10]

        return topic_id_to_book, book_to_text


    def TextToTopTopicId(self, doc_text):
        """Returns the topic for a given document.

        :param doc_text: A plain text of one document
        :return: A sorted (by val) list of tuples [(topic name, val in [0,1])]
        """
        if not doc_text:
            return -1, -1
        lower_doc_text = doc_text.lower()
        tokens = self._tokenizer.tokenize(lower_doc_text)

        bow = self._dictionary.doc2bow(tokens)
        doc_topics = self._ldamodel.get_document_topics(bow)

        if not doc_topics:
            return -1, -1
        top_doc_topic_id, score = sorted(doc_topics, key=lambda x: x[1], reverse=True)[0]
        return top_doc_topic_id, score

    def TextToChapters(self, text):
        topic_id, _ = self.TextToTopTopicId(text)
        mm = self._topic_id_to_chapters.get(topic_id, [])
        mm_with_text = [(x[0].split('@'), self._book_to_text.get(x[0], '')) for x in mm]
        return mm_with_text


class TzabarServer(object):
    def __init__(self, lda_model):
        self._app = Flask(__name__, template_folder='templates')
        self._lda_model = lda_model
        self._app.add_url_rule('/', 'self._Post', self._Post)


    def _Post(self):
        param = flask.request.args.get('q')
        print param
        mm = self._lda_model.TextToChapters(param)
        print mm
        return jsonify(mm)



if __name__ == "__main__":
    lda_model = LdaModel(model_file_name, dictionary_file_name)
    server = TzabarServer(lda_model)
    server._app.run(debug=False, port=8888)
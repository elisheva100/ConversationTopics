import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';

import { ConnectionBackend } from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import {Observable} from "rxjs/Observable";

@Injectable()
export class AppService {

  constructor(private http: Http) { }

  getData(q): Observable<any[]> {
    let apiURL = "http://127.0.0.1:8000/?q=" + q;
    return this.http.get(apiURL)
      .map(res => {
          return res.json();
        }
        );
      }
  getDataGivenBible(data): Observable<any[]> {
    let apiURL = "https://www.sefaria.org.il/api/texts/" + data;
    return this.http.get(apiURL)
      .map(res => {
          return res.json();
        }
        );
      }

  getDataGivenWord(data): Observable<any[]> {
    let apiURL = "http://127.0.0.1:8888/?q=" + data;
    return this.http.get(apiURL)
      .map(res => {
          return res.json();
        }
      );
  }




}

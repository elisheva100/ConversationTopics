import { Component, OnInit } from '@angular/core';
import {AppService} from "../app.service";
import {ActivatedRoute, Params, Router} from '@angular/router';
@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit{
  inputValue;
  chapValue;
  textPart;
  sizeArr = [];


  constructor(private activatedRoute: ActivatedRoute, private appService: AppService,private router: Router) {
  }
  ngOnInit() {
    this.sizeArr = [];
    this.activatedRoute.params.subscribe((params: Params) => {
      let query  = params['name'];
      if(query) {
        this.inputValue = query.split('.')[0];
        this.chapValue = query.split('.')[1];
        console.log(this.inputValue);
        console.log(this.chapValue);
        this.onSearchClicked();
      }

    });
  }
  onSearchClicked() {
    this.textPart ='';
    const search = this.inputValue + '.' + this.chapValue;
    this.appService.getDataGivenBible(search).subscribe((response) => {

      const q = JSON.parse(JSON.stringify(response));
      this.appService.getData(q.text.join(" ")).subscribe(res => {
        console.log(res);
        this.sizeArr = res;
        this.sizeArr.forEach(item => {
          item[1] = Math.sqrt(item[1]);
        });
      });

      this.textPart = q.text;
    });
  }
  onCircleClicked(search) {
    this.router.navigate(['/circle/' + search]);
  }
}

import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import {FormsModule} from "@angular/forms";
import {AppService} from "./app.service";
import {HttpModule} from "@angular/http";
import {SearchComponent} from "./search/search.component";
import {RouterModule, Routes} from "@angular/router";
import {CommonModule} from "@angular/common";
import { CircleSearchComponent } from './circle-search/circle-search.component';
const routes: Routes = [
  { path: '', component: SearchComponent },
  { path: 'circle/:name', component: CircleSearchComponent },
  { path: 'res/:name', component: SearchComponent }
];
@NgModule({
  declarations: [
    AppComponent,
    SearchComponent,
    CircleSearchComponent

  ],
  imports: [
    [ RouterModule.forRoot(routes) ],
    BrowserModule,
    CommonModule,
    FormsModule,
    HttpModule
  ],
  exports: [ RouterModule ],
  providers: [AppService],
  bootstrap: [AppComponent]
})
export class AppModule { }

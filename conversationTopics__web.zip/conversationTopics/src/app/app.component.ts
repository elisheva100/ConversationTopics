import {Component, OnInit} from '@angular/core';
import {AppService} from "./app.service";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit{
  inputValue;
  chapValue;
  textPart;
  sizeArr = [];


  constructor(private appService: AppService) {
  }
  ngOnInit() {
    this.sizeArr = [];
  }
  onSearchClicked() {
    this.textPart ='';
    // this.sizeArr = []
    const search = this.inputValue + '.' + this.chapValue;
    this.appService.getDataGivenBible(search).subscribe((response) => {

      const q = JSON.parse(JSON.stringify(response))
      this.appService.getData(q.text.join(" ")).subscribe(res => {
        console.log(res);
        this.sizeArr = res;
        this.sizeArr.forEach(item => {
          item[1] = Math.sqrt(item[1]);
        });
      })

       this.textPart = q.text;
    });
  }
  onCircleClicked(search) {
    console.log(search);
  }

 }

import {Component, Input, OnInit} from '@angular/core';
import {ActivatedRoute, Params, Router} from "@angular/router";
import {AppService} from "../app.service";

@Component({
  selector: 'app-circle-search',
  templateUrl: './circle-search.component.html',
  styleUrls: ['./circle-search.component.css']
})
export class CircleSearchComponent implements OnInit {
  circleVal;
  dataArr;
  constructor(private appService : AppService , private activatedRoute: ActivatedRoute,private router: Router) { }

  ngOnInit() {
    this.activatedRoute.params.subscribe((params: Params) => {
      this.circleVal = params['name'];
      console.log(this.circleVal);
      this.onSearchClickedNext(this.circleVal);
    });
  }
  onSearchClickedNext(word: string){
    this.appService.getDataGivenWord(word).subscribe(res =>{
      this.dataArr = res;
      console.log(this.dataArr);
    });
  }
  onMarClicked(item) {
    let temp = item[0][0]+'.'+item[0][1];
    console.log(temp);
    this.router.navigate(['res/'+temp]);
  }

}
